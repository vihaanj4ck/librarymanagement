package com.library;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LibrarySystem {
    private final List<Book> books = new ArrayList<>();
    private final List<Member> members = new ArrayList<>();
    private final List<Transaction> transactions = new ArrayList<>();

    public LibrarySystem() {
        loadBooks();
        loadMembers();
        loadTransactions();
    }

    public List<Book> getBooks() { return books; }
    public List<Member> getMembers() { return members; }
    public List<Transaction> getTransactions() { return transactions; }

    public long getTotalBooks() {
        return books.size();
    }

    public long getAvailableBooks() {
        return books.stream().filter(Book::isAvailable).count();
    }

    public long getIssuedBooks() {
        return getTotalBooks() - getAvailableBooks();
    }

    public void loadBooks() {
        books.clear();
        String sql = "SELECT id, title, author, isbn, genre, available FROM books";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Book b = new Book(
                        String.valueOf(rs.getInt("id")),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("isbn"),
                        rs.getString("genre")
                );
                b.setAvailable(rs.getBoolean("available"));
                books.add(b);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadMembers() {
        members.clear();
        String sql = "SELECT id, name, email FROM members";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Member m = new Member(
                        String.valueOf(rs.getInt("id")),
                        rs.getString("name"),
                        rs.getString("email")
                );
                members.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadTransactions() {
        transactions.clear();
        String sql = """
                SELECT t.id, t.book_id, t.member_id, t.borrow_date, t.return_date,
                       b.title, b.author, b.isbn, b.genre, b.available,
                       m.name, m.email
                FROM transactions t
                JOIN books b ON t.book_id = b.id
                JOIN members m ON t.member_id = m.id
                """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Book b = new Book(
                        String.valueOf(rs.getInt("book_id")),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("isbn"),
                        rs.getString("genre")
                );
                b.setAvailable(rs.getBoolean("available"));

                Member m = new Member(
                        String.valueOf(rs.getInt("member_id")),
                        rs.getString("name"),
                        rs.getString("email")
                );

                Transaction tx = new Transaction(
                        String.valueOf(rs.getInt("id")),
                        b,
                        m,
                        rs.getDate("borrow_date").toLocalDate()
                );
                Date rd = rs.getDate("return_date");
                if (rd != null) {
                    tx.setReturnDate(rd.toLocalDate());
                }
                transactions.add(tx);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Book createBook(String title, String author, String isbn, String genre) {
        String sql = "INSERT INTO books (title, author, isbn, genre, available) VALUES (?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, title);
            ps.setString(2, author);
            ps.setString(3, isbn);
            ps.setString(4, genre);
            ps.setBoolean(5, true);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    String id = String.valueOf(rs.getInt(1));
                    Book book = new Book(id, title, author, isbn, genre);
                    book.setAvailable(true);
                    books.add(book);
                    return book;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Member createMember(String name, String email) {
        String sql = "INSERT INTO members (name, email) VALUES (?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, name);
            ps.setString(2, email);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    String id = String.valueOf(rs.getInt(1));
                    Member m = new Member(id, name, email);
                    members.add(m);
                    return m;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Transaction borrowBook(Book book, Member member) {
        if (!book.isAvailable()) return null;

        String sql = "INSERT INTO transactions (book_id, member_id, borrow_date) VALUES (?,?,?)";
        String updateBook = "UPDATE books SET available = ? WHERE id = ?";
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps1 = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                 PreparedStatement ps2 = conn.prepareStatement(updateBook)) {

                ps1.setInt(1, Integer.parseInt(book.getId()));
                ps1.setInt(2, Integer.parseInt(member.getId()));
                ps1.setDate(3, Date.valueOf(LocalDate.now()));
                ps1.executeUpdate();

                try (ResultSet rs = ps1.getGeneratedKeys()) {
                    if (rs.next()) {
                        String txId = String.valueOf(rs.getInt(1));

                        ps2.setBoolean(1, false);
                        ps2.setInt(2, Integer.parseInt(book.getId()));
                        ps2.executeUpdate();

                        conn.commit();

                        book.setAvailable(false);
                        Transaction tx = new Transaction(txId, book, member, LocalDate.now());
                        transactions.add(tx);
                        return tx;
                    }
                }
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean returnBook(Transaction tx) {
        if (tx.getReturnDate() != null) return false;

        String sql = "UPDATE transactions SET return_date = ? WHERE id = ?";
        String updateBook = "UPDATE books SET available = ? WHERE id = ?";
        LocalDate today = LocalDate.now();

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps1 = conn.prepareStatement(sql);
                 PreparedStatement ps2 = conn.prepareStatement(updateBook)) {

                ps1.setDate(1, Date.valueOf(today));
                ps1.setInt(2, Integer.parseInt(tx.getId()));
                ps1.executeUpdate();

                ps2.setBoolean(1, true);
                ps2.setInt(2, Integer.parseInt(tx.getBook().getId()));
                ps2.executeUpdate();

                conn.commit();

                tx.setReturnDate(today);
                tx.getBook().setAvailable(true);
                return true;
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
